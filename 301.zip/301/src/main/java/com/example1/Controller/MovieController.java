package com.example1.Controller;

import com.alibaba.fastjson.JSONObject;
import com.example1.Config.MovieMapper;
import com.example1.models.Movie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class MovieController {

    @Autowired
    private MovieMapper movieMapper;

    @PostMapping("/movies")
    public String addMoviesREST(@RequestBody JSONObject jsonObject)
    {
        if (jsonObject == null || !jsonObject.containsKey("movie") || jsonObject.getString("movie") == null
                || jsonObject.getString("movie").trim().isEmpty()) {
            return "Please enter a non-empty movie name!";
        }
        String movieName = jsonObject.getString("movie").trim();
        Movie movie = new Movie(movieName);
        if (movieMapper.isMovieNameExist(movie) > 0) {
            return "The Movie \"" + movieName + "\" already exists";
        }
        if (movieMapper.insertMovie(movie)) {
            return "Movie is added successfully \"" + movieName + "\"";
        } else {
            return "Something went wrong in inserting the movie "+ movieName + "\nPlease try again!";
        }
    }

    @RequestMapping("/movies/search/{ch}/{limit}")
    public List<String> returnMoviesListREST(@PathVariable("ch") Character ch, @PathVariable("limit") Integer limit) {
        List<Movie> movieList = movieMapper.getMoviesList();
        List<String> stringList = movieList.stream().
                filter(e -> e.getMovieName().substring(0, 1).equalsIgnoreCase(String.valueOf(ch))).
                map(e -> e.getMovieName()).collect(Collectors.toList());
        if (stringList.size() >= limit) {
            return stringList.subList(0, limit);
        } else {
            return stringList;
        }
    }
}
