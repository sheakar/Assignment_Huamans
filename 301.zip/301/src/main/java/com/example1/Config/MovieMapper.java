package com.example1.Config;

import com.example1.models.Movie;
import org.apache.ibatis.annotations.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Order(1)
@Mapper
@Qualifier("metricSqlFactoryBean")
public interface MovieMapper {

    @Results({
            @Result(property = "movieName", column = "name"),
            @Result(property = "id", column = "id")
    })

    @Select("select name from moviedb.movie")
    public List<Movie> getMoviesList();

    @Insert("insert into moviedb.movie(name) values(#{movieName})")
    public boolean insertMovie(Movie movie);

    @Select("select count(*) from moviedb.movie where name = #{movieName}")
    public int isMovieNameExist(Movie movie);
}
