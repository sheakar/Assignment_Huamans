package com.example1.Config;

import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperFactoryBean;
import org.springframework.beans.factory.annotation. Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context. annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
@Configuration
@ComponentScan(basePackages = "com.example1")
public class BeanConfig {
    @Bean(name = "MovieMapper")
    protected MapperFactoryBean<MovieMapper> movieMapper(SqlSessionFactoryBean sqlSessionFactoryBean) throws Exception {
        MapperFactoryBean<MovieMapper> factoryBean = new MapperFactoryBean<>(MovieMapper.class);
        factoryBean.setSqlSessionFactory(sqlSessionFactoryBean.getObject());
        return factoryBean;
    }

    @Bean(name = "metricSqlFactoryBean")
    protected SqlSessionFactoryBean metricSqFactoryBean(@Qualifier("metricDataSource")
        final DataSource metricDataSource) throws Exception {
        SqlSessionFactoryBean sqlFactoryBean = new SqlSessionFactoryBean();
        sqlFactoryBean.setDataSource(metricDataSource);
        SqlSessionFactory sqlSessionFactory = sqlFactoryBean.getObject();
        if (null != sqlSessionFactory) {
            sqlSessionFactory.getConfiguration().addMapper(MovieMapper.class);
        } else {
        }
        return sqlFactoryBean;
    }

    @Bean(name = "metricDataSource")
    protected DataSource metricDataSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl("jdbc:mysql://localhost:3306");
        dataSource.setUsername("root");

        dataSource.setPassword("Unique@7856");
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        return dataSource;
    }
}
